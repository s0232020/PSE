#ifndef PROJECTTITLE_INCLUDE_H
#define PROJECTTITLE_INCLUDE_H

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include "Exceptions.h"
#include "DesignByContract.h"
#include "tinyxml.h"
#include "main.h"
#include <gtest/gtest.h>

#endif //PROJECTTITLE_INCLUDE_H
