var searchData=
[
  ['savefile_0',['SaveFile',['../class_ti_xml_document.html#ab63b96a6af5a467e289c7c75202edad9',1,'TiXmlDocument::SaveFile() const'],['../class_ti_xml_document.html#ae641f33784381017c44e107cc2c86b5c',1,'TiXmlDocument::SaveFile(const char *filename) const'],['../class_ti_xml_document.html#a8f5a1022168a5767e32becec7b6f44ee',1,'TiXmlDocument::SaveFile(FILE *) const']]],
  ['setattribute_1',['SetAttribute',['../class_ti_xml_element.html#abf0b3bd7f0e4c746a89ec6e7f101fc32',1,'TiXmlElement::SetAttribute(const char *name, const char *_value)'],['../class_ti_xml_element.html#ace6f4be75e373726d4774073d666d1a7',1,'TiXmlElement::SetAttribute(const char *name, int value)']]],
  ['setcdata_2',['SetCDATA',['../class_ti_xml_text.html#acb17ff7c5d09b2c839393445a3de5ea9',1,'TiXmlText']]],
  ['setcondensewhitespace_3',['SetCondenseWhiteSpace',['../class_ti_xml_base.html#a0f799ec645bfb8d8a969e83478f379c1',1,'TiXmlBase']]],
  ['setdoubleattribute_4',['SetDoubleAttribute',['../class_ti_xml_element.html#a0d1dd975d75496778177e35abfe0ec0b',1,'TiXmlElement']]],
  ['setdoublevalue_5',['SetDoubleValue',['../class_ti_xml_attribute.html#a0316da31373496c4368ad549bf711394',1,'TiXmlAttribute']]],
  ['setindent_6',['SetIndent',['../class_ti_xml_printer.html#a213377a4070c7e625bae59716b089e5e',1,'TiXmlPrinter']]],
  ['setintvalue_7',['SetIntValue',['../class_ti_xml_attribute.html#a7e065df640116a62ea4f4b7da5449cc8',1,'TiXmlAttribute']]],
  ['setlinebreak_8',['SetLineBreak',['../class_ti_xml_printer.html#a4be1e37e69e3858c59635aa947174fe6',1,'TiXmlPrinter']]],
  ['setname_9',['SetName',['../class_ti_xml_attribute.html#ab7fa3d21ff8d7c5764cf9af15b667a99',1,'TiXmlAttribute']]],
  ['setstreamprinting_10',['SetStreamPrinting',['../class_ti_xml_printer.html#ab23a90629e374cb1cadca090468bbd19',1,'TiXmlPrinter']]],
  ['settabsize_11',['SetTabSize',['../class_ti_xml_document.html#a51dac56316f89b35bdb7d0d433ba988e',1,'TiXmlDocument']]],
  ['setup_12',['SetUp',['../class_printing_system_test.html#acc78bd2dc9351418fe215176a5389517',1,'PrintingSystemTest']]],
  ['setuserdata_13',['SetUserData',['../class_ti_xml_base.html#ac6b3e0f790930d4970ec30764e937b5d',1,'TiXmlBase']]],
  ['setvalue_14',['SetValue',['../class_ti_xml_node.html#a2a38329ca5d3f28f98ce932b8299ae90',1,'TiXmlNode::SetValue()'],['../class_ti_xml_attribute.html#a2dae44178f668b3cb48101be4f2236a0',1,'TiXmlAttribute::SetValue()']]],
  ['size_15',['Size',['../class_ti_xml_printer.html#ad01375ae9199bd2f48252eaddce3039d',1,'TiXmlPrinter']]],
  ['standalone_16',['Standalone',['../class_ti_xml_declaration.html#a11fc7756966a9f993e0b962495298f24',1,'TiXmlDeclaration']]]
];
