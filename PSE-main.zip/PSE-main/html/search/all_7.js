var searchData=
[
  ['job_0',['Job',['../class_job.html',1,'Job'],['../class_job.html#a35b685e9c52316510a3caeac02f7b7d6',1,'Job::Job()']]]
];
