var searchData=
[
  ['deprecated_20list_0',['Deprecated List',['../deprecated.html',1,'']]],
  ['doublevalue_1',['DoubleValue',['../class_ti_xml_attribute.html#a8cca240fb2a7130c87b0fc6156e8b34f',1,'TiXmlAttribute']]]
];
