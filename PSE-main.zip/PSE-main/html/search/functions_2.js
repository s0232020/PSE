var searchData=
[
  ['doublevalue_0',['DoubleValue',['../class_ti_xml_attribute.html#a8cca240fb2a7130c87b0fc6156e8b34f',1,'TiXmlAttribute']]]
];
