var searchData=
[
  ['userdata_0',['userData',['../class_ti_xml_base.html#ab242c01590191f644569fa89a080d97c',1,'TiXmlBase']]]
];
